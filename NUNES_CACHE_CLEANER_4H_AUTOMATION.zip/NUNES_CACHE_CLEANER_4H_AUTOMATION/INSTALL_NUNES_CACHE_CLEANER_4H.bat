@echo off
setlocal EnableExtensions
title NUNES CACHE CLEANER - 4 HOUR AUTOMATION SETUP
color 0A

:: =========================================================
:: ONE-TIME INSTALLER
:: Keeps the cleaner behavior unchanged for manual use.
:: Installs a hidden Windows Scheduled Task that:
::   - runs immediately after setup
::   - runs every 4 hours
::   - runs at Windows startup
::   - runs as SYSTEM with highest privileges
::   - catches a missed run when the PC becomes available
:: =========================================================

set "SOURCE=%~dp0NUNES_CACHE_CLEANER_V2_4H.bat"
set "INSTALL_DIR=%ProgramData%\Nunes\CacheCleaner"
set "INSTALL_FILE=%INSTALL_DIR%\NUNES_CACHE_CLEANER.bat"
set "TASK_NAME=NUNES Cache Cleaner - Every 4 Hours"

if not exist "%SOURCE%" (
    echo.
    echo [ERROR] Cannot find:
    echo %SOURCE%
    echo.
    echo Keep this installer and NUNES_CACHE_CLEANER_V2_4H.bat
    echo in the same folder, then run the installer again.
    echo.
    pause
    exit /b 1
)

:: ---------------------------------------------------------
:: ADMIN RIGHTS REQUIRED ONLY FOR ONE-TIME TASK INSTALLATION
:: ---------------------------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Requesting Administrator permission for one-time setup...
    echo.
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cls
echo ========================================================
echo.
echo       NUNES CACHE CLEANER - 4 HOUR AUTOMATION SETUP
echo.
echo ========================================================
echo.
echo Cleaner actions remain the same:
echo   [1] User TEMP only
echo   [2] C:\Windows\Temp only

echo Schedule:
echo   - Every 4 hours, every day
echo   - Also at Windows startup
echo   - Hidden background task
echo   - No Y/N prompt during automatic runs
echo.
echo ========================================================
echo.

if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%" >nul 2>&1
if not exist "%INSTALL_DIR%" (
    echo [ERROR] Could not create install folder:
    echo %INSTALL_DIR%
    echo.
    pause
    exit /b 1
)

copy /Y "%SOURCE%" "%INSTALL_FILE%" >nul
if errorlevel 1 (
    echo [ERROR] Could not copy cleaner to:
    echo %INSTALL_FILE%
    echo.
    pause
    exit /b 1
)

set "NUNES_TASK_SCRIPT=%INSTALL_FILE%"
set "NUNES_USER_TEMP=%TEMP%"
set "NUNES_TASK_NAME=%TASK_NAME%"
set "PS1=%TEMP%\NUNES_CACHE_CLEANER_TASK_SETUP_%RANDOM%.ps1"

> "%PS1%" echo $ErrorActionPreference = 'Stop'
>>"%PS1%" echo $taskName = $env:NUNES_TASK_NAME
>>"%PS1%" echo $scriptPath = $env:NUNES_TASK_SCRIPT
>>"%PS1%" echo $userTemp = $env:NUNES_USER_TEMP
>>"%PS1%" echo $cmd = Join-Path $env:SystemRoot 'System32\cmd.exe'
>>"%PS1%" echo $arguments = '/d /c ""' + $scriptPath + '" /AUTO "' + $userTemp + '""'
>>"%PS1%" echo $action = New-ScheduledTaskAction -Execute $cmd -Argument $arguments
>>"%PS1%" echo $startup = New-ScheduledTaskTrigger -AtStartup
>>"%PS1%" echo $repeat = New-ScheduledTaskTrigger -Once -At (Get-Date).AddHours(4) -RepetitionInterval (New-TimeSpan -Hours 4) -RepetitionDuration (New-TimeSpan -Days 3650)
>>"%PS1%" echo $principal = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
>>"%PS1%" echo $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -Hidden -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 1)
>>"%PS1%" echo Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($startup,$repeat) -Principal $principal -Settings $settings -Description 'NUNES Cache Cleaner: cleans the configured user TEMP and C:\Windows\Temp every 4 hours while the PC is available.' -Force ^| Out-Null
>>"%PS1%" echo Start-ScheduledTask -TaskName $taskName
>>"%PS1%" echo Start-Sleep -Seconds 2
>>"%PS1%" echo $task = Get-ScheduledTask -TaskName $taskName
>>"%PS1%" echo $info = Get-ScheduledTaskInfo -TaskName $taskName
>>"%PS1%" echo Write-Host ('TASK_STATE=' + $task.State)
>>"%PS1%" echo Write-Host ('NEXT_RUN=' + $info.NextRunTime)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"
del /Q "%PS1%" >nul 2>&1

if not "%RC%"=="0" (
    echo.
    echo [ERROR] Scheduled Task setup failed.
    echo The cleaner file was copied, but automation was not completed.
    echo.
    pause
    exit /b %RC%
)

echo.
echo ========================================================
echo.
echo                 SETUP COMPLETED
echo.
echo ========================================================
echo.
echo Task name : %TASK_NAME%
echo Installed : %INSTALL_FILE%
echo Frequency : Every 4 hours + Windows startup
echo Mode      : Hidden automatic run
echo.
echo The first automatic cleanup has been started now.
echo Future runs do not need you to click Y or approve UAC.
echo.
echo You can still double-click the cleaner manually and it will
echo behave like before with the Y/N confirmation.
echo.
echo ========================================================
echo.
pause
exit /b 0
